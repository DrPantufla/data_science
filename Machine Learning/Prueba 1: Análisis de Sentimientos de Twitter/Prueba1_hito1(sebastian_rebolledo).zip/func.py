import pandas as pd
import numpy as np

def recod_sentiment(data, words, num):
    '''
    Esta funcion se utilizará para recodificar el atributo sentiment en un dataset cualquiera.
    Se ingresan los valores de data, words y num:
    data = dataframe donde se encuentra el atributo sentiment.
    words = va a ser una lista de palabras que serán reformuladas con esta funcion.
    num = será el nuevo valor que tomara el dataset.
    '''
    for emotion in words:
        data['sentiment']=np.where(data['sentiment']==emotion, num, data['sentiment'])
    return 