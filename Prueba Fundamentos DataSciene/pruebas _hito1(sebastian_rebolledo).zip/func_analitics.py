def suma(num1, num2):
    """
    En la siguiente funcion entran 2 numeros: num1 y num2, los cuales se suman y 
    la salida entrega la suma del resultado.
    """
    return num1+num2

